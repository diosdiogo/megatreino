<?php
$conexao = mysqli_connect('localhost','root','root','academia'); // Banco Local - Teste