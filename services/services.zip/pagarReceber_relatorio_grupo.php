<?php

include 'conecta.php';

$id = $_GET["id"];
$state = $_GET["state"];
$dataI = $_GET['dataI'];
$dataF = $_GET['dataF'];

$pagamento = $_GET["pagamento"];

$pg1 = 'canc=';
$pg2 = $pagamento;
$pg3 = ' and';

if ($state == "C") {

	if ($pagamento == 1) {
		$lista = '{"result":[' . json_encode(getPagarReceber($conexao, $id, $dataI, $dataF)) . ']}';
		echo $lista;
	} else {
		$lista = '{"result":[' . json_encode(getPagarReceberPagamento($conexao, $id, $dataI, $dataF, $pg1, $pg2, $pg3)) . ']}';
		echo $lista;
	}
}

function getPagarReceber($conexao, $id, $dataI, $dataF) {
	$retorno = array();

	$sql = "select canc, sum(val_pago) as valpago, forma_pagamento.descricao from academia.pagar_receber inner join forma_pagamento on(pagar_receber.canc=forma_pagamento.sigla) where pagar_receber.academia={$id} and
pagar_receber.pago = 1 and pagamento >= '{$dataI}' and pagamento <= '{$dataF}' group by canc
order by date(pagamento) desc";

	$resultado = mysqli_query($conexao, $sql);

	while ($row = mysqli_fetch_assoc($resultado)) {

		array_push($retorno, array(
			'canc' => $row['canc'],
			'valpago' => $row['valpago'],
			'descricao' => $row['descricao']));
	}

	return $retorno;
}

function getPagarReceberPagamento($conexao, $id, $dataI, $dataF, $pg1, $pg2, $pg3) {
	$retorno = array();

	$sql = "select canc, sum(val_pago) as valpago, forma_pagamento.descricao from academia.pagar_receber inner join forma_pagamento on(pagar_receber.canc=forma_pagamento.sigla) where pagar_receber.academia={$id} and {$pg1}'{$pg2}' {$pg3}
pagar_receber.pago = 1 and pagamento >= '{$dataI}' and pagamento <= '{$dataF}'group by canc
order by date(pagamento) desc";

	$resultado = mysqli_query($conexao, $sql);

	while ($row = mysqli_fetch_assoc($resultado)) {

		array_push($retorno, array(
			'canc' => $row['canc'],
			'valpago' => $row['valpago'],
			'descricao' => $row['descricao']));
	}

	return $retorno;
}
