<?php

include 'conecta.php';

$id = $_GET["id"];
$state = $_GET["state"];

if ($state == "C") {
	$lista = '{"result":[' . json_encode(getPerfil($conexao, $id)) . ']}';
	echo $lista;
}

function getPerfil($conexao, $id) {
	$retorno = array();

	$sql = "select * from perfil where academia={$id}";

	$resultado = mysqli_query($conexao, $sql);
	while ($row = mysqli_fetch_assoc($resultado)) {
		array_push($retorno, array('idperfil' => $row['idperfil'], 'nome' => utf8_encode($row['nome']), 'academia' => $row['academia']));
	}

	return $retorno;
}