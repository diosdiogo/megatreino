<?php

include 'conecta.php';

$id = $_GET["id"];
$state = $_GET["state"];

if ($state == "C") {
	$lista = '{"result":[' . json_encode(getCartao_recebido($conexao, $id)) . ']}';
	echo $lista;
}

function getCartao_recebido($conexao, $id) {
	$retorno = array();

	$sql = "select cartao_recebido.id, cartao_recebido.emissao, cartao_recebido.venc,cartao_recebido.ocorrencia,cartao_recebido.valor,cartao_recebido.parcela, cartao_recebido.cartao, cartao.id,cartao.descricao from cartao_recebido inner join cartao on (cartao_recebido.cartao  = cartao.id) where cartao_recebido.academia={$id}";

	
	

	$resultado = mysqli_query($conexao, $sql);
	while ($row = mysqli_fetch_assoc($resultado)) {
		
		
		array_push($retorno, array('id' => $row['id'], 'emissao' => $row['emissao'], 'venc' => $row['venc'], 'ocorrencia' => $row['ocorrencia'], 'valor' => $row['valor'], 'parcela' => $row['parcela'], 'descricao' => $row['descricao']));
	}

	return $retorno;
}